package com.thehecklers.sburrestdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SburRestDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
